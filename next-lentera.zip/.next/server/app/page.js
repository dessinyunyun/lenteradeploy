(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 7999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 1090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 8652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 8446:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9394)), "C:\\Users\\dessi\\Documents\\belajar\\CODEX\\TESPROJECTDESAIN\\next lentera\\next-lentera\\src\\app\\page.jsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1764))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 923)), "C:\\Users\\dessi\\Documents\\belajar\\CODEX\\TESPROJECTDESAIN\\next lentera\\next-lentera\\src\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1764))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\dessi\\Documents\\belajar\\CODEX\\TESPROJECTDESAIN\\next lentera\\next-lentera\\src\\app\\page.jsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/page"
  

/***/ }),

/***/ 2485:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9222, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 8301, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3751, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4765, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5192, 23))

/***/ }),

/***/ 8470:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5591));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1689))

/***/ }),

/***/ 9030:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3145))

/***/ }),

/***/ 3145:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/halamanUtama/Product/Product.jsx



const LazyProductCarousel = /*#__PURE__*/ (0,react_.lazy)(()=>__webpack_require__.e(/* import() */ 150).then(__webpack_require__.bind(__webpack_require__, 2150)));
function Product(props) {
    const audioVisual = (0,react_.useRef)(null);
    const networkingAndComputer = (0,react_.useRef)(null);
    const [audioVisualHeight, setAudioVisualHeight] = (0,react_.useState)(0);
    const [networkingAndComputerHeight, setNetworkingAndComputerHeight] = (0,react_.useState)(0);
    const [networkingAndComputerHeightMobile, setNetworkingAndComputerHeightMobile] = (0,react_.useState)(0);
    const [networkingAndComputerWidth, setNetworkingAndComputerWidth] = (0,react_.useState)(0);
    const [showOverlay, setShowOverlay] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        if (audioVisual.current || networkingAndComputer.current) {
            const widthAudio = audioVisual.current.offsetWidth;
            const newHeightAudio = widthAudio * 60.5 / 100;
            const widthNetComp = networkingAndComputer.current.offsetWidth;
            const heightNetComp = networkingAndComputer.current.offsetHeight;
            const newHeighNetComp = widthNetComp * 60.25 / 100;
            (0,react_.startTransition)(()=>{
                setAudioVisualHeight(newHeightAudio);
                setNetworkingAndComputerHeightMobile(heightNetComp);
                setNetworkingAndComputerWidth(widthNetComp);
                // Kode yang memperbarui state BrandPartner
                // Misalnya, panggil fungsi setState atau lakukan operasi lainnya
                setNetworkingAndComputerHeight(newHeighNetComp);
            });
        }
    }, [
        props.sizeScreen
    ]);
    (0,react_.useEffect)(()=>{
        const handleScroll = ()=>{
            const divElement = document.getElementById("networking");
            const rect = divElement.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            setShowOverlay(rect.top < windowHeight && rect.bottom >= 0);
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>{
            window.removeEventListener("scroll", handleScroll);
        };
    }, []);
    const [show, setShow] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        if (props.sizeScreen, length > 0) {
            setShow(true);
        } else {
            setShow(false);
        }
    }, [
        props
    ]);
    console.log(props);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "product-contain mt-14 flex flex-col  m-auto w-4/5",
        style: {
            rowGap: `${5.5}px`
        },
        id: "product",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid md:grid-cols-3 sm:gap-x-1.5 gap-y-1.5 h-1/2 w-full",
                style: {
                    paddingRight: `${2.5}px`,
                    paddingLeft: `${3}px`
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "Audio Visual sm:col-span-2 bg-slate-400  box-border relative ",
                        ref: audioVisual,
                        style: {
                            height: props.sizeScreen === "hp" ? `208px` : `${audioVisualHeight + 1}px`
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/WhatsApp-Image-2023-04-27-at-16.35.07-e1683625549145.jpeg?size=Thumbnail",
                                className: "w-full h-full object-cover",
                                alt: "audio visual",
                                layout: "fill"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `${showOverlay && "gradient-overlay"} absolute inset-0`,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "text text-white absolute bottom-3 left-3 text-start text-base lg:text-xl",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Audio Visual"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "font-semibold m-0",
                                            children: "Bring your ideas to life with our audio visual services that combine creativity and technology."
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "networkong-computer w-full box-border flex flex-col justify-center gap-y-1.5",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                id: "networking",
                                className: "networking w-full h-full relative ",
                                ref: networkingAndComputer,
                                style: {
                                    height: props.sizeScreen === "laptop" || props.sizeScreen === "tablet" ? `${networkingAndComputerHeight}px` : `208px`
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/6372f7e07746ccd481b5082d_nasa-min.jpg?size=Thumbnail",
                                        className: "w-full h-full object-cover",
                                        layout: "fill",
                                        alt: "audio visual"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: `${showOverlay && "gradient-overlay"} absolute inset-0`,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text text-white absolute bottom-3 left-3 text-start text-base sm:text-xs lg:text-base",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    children: "Networking"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "font-semibold m-0",
                                                    children: "Experience seamless and reliable connectivity with our advanced networking solution."
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "computer-printer w-full h-full  relative",
                                ref: networkingAndComputer,
                                style: {
                                    height: props.sizeScreen === "laptop" || props.sizeScreen === "tablet" ? `${networkingAndComputerHeight}px` : `208px`
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/printer-computer-office-table_93675-3798.jpg?size=Thumbnail",
                                        className: "w-full h-full object-cover",
                                        layout: "fill",
                                        alt: "audio visual"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: `${showOverlay && "gradient-overlay"} absolute inset-0`,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text text-white absolute bottom-3 left-3 text-start text-base sm:text-xs lg:text-base",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    children: "Computer and Printer"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "font-semibold m-0",
                                                    children: "Our experienced team can provide you with computer and printer services that are customized to your specific business needs."
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Suspense, {
                fallback: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Loading..."
                }),
                children: /*#__PURE__*/ jsx_runtime_.jsx(LazyProductCarousel, {
                    networkingAndComputerHeight: networkingAndComputerHeight,
                    networkingAndComputerWidth: networkingAndComputerWidth,
                    sizeScreen: props.sizeScreen
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/components/halamanUtama/aboutUs/index.jsx


function index() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "about-us-contain mt-20 h-96 sm:h-80 text-white flex justify-center items-center text-sm sm:text-base",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "text-contain w-4/5 sm:w-3/5 absolute z-10 ",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: "text-center font-regular",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "font-bold ",
                        children: "Lentera inovasi"
                    }),
                    " berdiri pada tahun 2022. kami berinovasi mengembangkan",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "font-bold",
                        children: " perusahaan bidang IT dan peralatan kantor"
                    }),
                    " . Kami mendedikasikan diri untuk pelayanan terbaik dengan dukungan tenaga ahli yang sudah berpengalaman.",
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "font-bold",
                        children: " kami berkomitmen "
                    }),
                    "untuk memberikan",
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "font-bold",
                        children: "solusi dan pelayanan terbaik kepada pelanggan kami."
                    }),
                    " Dengan perkembangan bisnis E-Commerce, kami akan terus berinovasi dan berusaha selalu menjadi pilihan utama pelanggan."
                ]
            })
        })
    });
}

// EXTERNAL MODULE: ./src/components/halamanUtama/brandPartner/index.jsx
var brandPartner = __webpack_require__(6091);
// EXTERNAL MODULE: ./src/components/halamanUtama/whychoseus/index.jsx + 1 modules
var whychoseus = __webpack_require__(7917);
;// CONCATENATED MODULE: ./src/components/halamanUtama/index.js






;// CONCATENATED MODULE: ./src/components/Main/Main.js

const Main = ({ children  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("main", {
        children: children
    });
};
/* harmony default export */ const Main_Main = (Main);

;// CONCATENATED MODULE: ./src/app/page.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const LazyWhyChooseUs = /*#__PURE__*/ (0,react_.lazy)(()=>Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 7917)));
const LazyBrandPartner = /*#__PURE__*/ (0,react_.lazy)(()=>Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 6091)));
function Home() {
    const [sizeScreen, setSizeScreen] = (0,react_.useState)("hp");
    const handleResize = (0,react_.useCallback)(()=>{
        const screenWidth = window.innerWidth;
        if (screenWidth > 1023) {
            setSizeScreen("laptop");
        } else if (screenWidth > 639) {
            setSizeScreen("tablet");
        } else {
            setSizeScreen("hp");
        }
    }, []);
    (0,react_.useEffect)(()=>{
        handleResize();
        window.addEventListener("resize", handleResize);
        return ()=>{
            window.removeEventListener("resize", handleResize);
        };
    }, [
        handleResize
    ]);
    (0,react_.useEffect)(()=>{
        const screenWidth = window.innerWidth;
        console.log(screenWidth);
        if (screenWidth > 1023) {
            setSizeScreen("laptop");
        } else if (screenWidth > 639) {
            setSizeScreen("tablet");
        } else {
            setSizeScreen("hp");
        }
    }, []);
    console.log(sizeScreen);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Main_Main, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative overflow-hidden bg-cover bg-no-repeat p-12 text-center",
                style: {
                    backgroundImage: "url('https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/bg.jpg?size=Thumbnail')",
                    height: sizeScreen == "hp" ? "700px" : "800px"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "absolute bottom-0 left-0 right-0 top-0 h-full w-full overflow-hidden bg-fixed",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "h-full flex items-center justify-center",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "text-white flex items-center justify-center flex-col",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "mb-4 text-2xl font-black",
                                    children: "ONE STOP IT SOLUTION"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "mb-6 text-sm lg:w-2/4  w-3/4 text-center font-bold",
                                    children: "Lentera Inovasi provides custom IT solutions designed to optimize processes, increase efficiency, and enhance competitiveness. Our experienced team delivers innovative and sustainable solutions that are tailored to your specific needs, future-proofing your IT infrastructure for years to come."
                                })
                            ]
                        })
                    })
                })
            }),
            sizeScreen.length > 0 && /*#__PURE__*/ jsx_runtime_.jsx(Product, {
                sizeScreen: sizeScreen
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Suspense, {
                fallback: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Loading..."
                }),
                children: /*#__PURE__*/ jsx_runtime_.jsx(LazyWhyChooseUs, {
                    sizeScreen: sizeScreen
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(index, {
                sizeScreen: sizeScreen
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Suspense, {
                fallback: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Loading..."
                }),
                children: /*#__PURE__*/ jsx_runtime_.jsx(LazyBrandPartner, {
                    sizeScreen: sizeScreen
                })
            })
        ]
    });
}


/***/ }),

/***/ 1689:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

// This is a client component 👈🏽
function Footer() {
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{}, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
        className: "bg-nav-fot py-3 px-10 flex flex-col items-center",
        id: "contact",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "primary flex flex-col sm:flex-row items-center sm:justify-around mt-5 w-full border-b border-slate-700 pb-5 pt-1",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "proud-partner flex flex-col items-center sm:w-1/3 content-center  text-slate-300",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "font-semibold text-sm sm:text-center text-center w-full sm:mb-1",
                                children: "Partner of:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/ekatalog1-removebg-preview.png",
                                alt: "logo ekatalog",
                                width: 150
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "Contact-us sm:text-center text-center sm:w-1/3 text-slate-300",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "font-semibold text-sm md:mt-0 mt-3",
                                children: "Contact Info:"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "contact  md:mt-3  text-sm",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "m-0",
                                        children: "support@lenterainovasi.co.id"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "m-0 text-sm",
                                        children: "+62 857-1013-2737"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "address md:text-center text-center sm:w-1/3 text-slate-300",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "font-semibold text-sm md:mt-0 mt-3",
                                children: "Address:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "contact md:my-3 text-sm",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "m-0",
                                    children: "Jl. Talang Bengkok IV Kota Semarang"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "copy-right w-full flex justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: "text-slate-400 m-0 mt-3 ",
                    children: [
                        "\xa9 ",
                        new Date().getFullYear(),
                        " Lentera Inovasi"
                    ]
                })
            })
        ]
    });
}


/***/ }),

/***/ 5591:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6775);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* __next_internal_client_entry_do_not_use__  auto */ 




const Nav = ()=>{
    const [scrolled, setScrolled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [isScrolling, setIsScrolling] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [menuOpen, setMenuOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [menuAnimation, setMenuAnimation] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const handleScroll = ()=>{
            const isScrolled = window.scrollY > 250;
            if (isScrolled !== scrolled) {
                setScrolled(isScrolled);
            }
        };
        document.addEventListener("scroll", handleScroll, {
            passive: true
        });
        return ()=>{
            document.removeEventListener("scroll", handleScroll);
        };
    }, [
        scrolled
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        let timeout;
        const handleScroll = ()=>{
            setIsScrolling(true);
            clearTimeout(timeout);
            timeout = setTimeout(()=>{
                setIsScrolling(false);
            }, 1000);
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>{
            window.removeEventListener("scroll", handleScroll);
            clearTimeout(timeout);
        };
    }, []);
    const navList = [
        {
            id: 1,
            name: "home",
            link: "#"
        },
        {
            id: 2,
            name: "Product",
            link: "#product"
        },
        {
            id: 3,
            name: "About",
            link: "#about"
        },
        {
            id: 4,
            name: "Contact",
            link: "#contact"
        }
    ];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const menuAnimationClass = menuOpen ? "menu-open" : "";
        setMenuAnimation(menuAnimationClass);
    }, [
        menuOpen
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
        className: `lg:px-32 sm:px-10 px-5 py-3 fixed top-0 navbar z-20 font-regular w-full ${scrolled && "scrolled"} ${!isScrolling && scrolled && !menuOpen && "opacity-0"} ${menuOpen ? "bg-white" : ""}`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex justify-between items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex items-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: "/",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: "/lenteralogo.png",
                            alt: "lentera Inovasi Logo",
                            width: 80,
                            height: 89
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-end space-x-4 relative w-full ",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            className: `hidden lg:flex sm:gap-3 text-xl ${menuOpen ? "flex" : "hidden"} list-destkop `,
                            children: navList.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: item.link,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            title: item.nspanme,
                                            children: item.name
                                        })
                                    })
                                }, item.id))
                        }),
                        menuOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `absolute top-10 w-11/12 sm:w-8/12 -right-10 h-screen transition-opacity duration-500 ${menuAnimation}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: "bg-nav-fot h-full py-16 flex flex-col gap-10 w-full box-border px-5 rounded-md",
                                children: navList.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "border-b pb-2 border-slate-500 w-3/5",
                                        onClick: ()=>setMenuOpen(!menuOpen),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: item.link,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                title: item.name,
                                                children: item.name
                                            })
                                        })
                                    }, item.id))
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "lg:hidden absolute -top-1 right-3 focus:outline-none text-white text-md font-medium ",
                            onClick: ()=>setMenuOpen(!menuOpen),
                            "aria-label": "Toggle Menu",
                            children: menuOpen ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__/* .FaTimes */ .aHS, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__/* .FaBars */ .Fm7, {})
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Nav); //testetestest


/***/ }),

/***/ 6091:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Index)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8217);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2330);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7738);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);






const listImage = [
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/Promethean_Logo_Primary_RGB_0621v1.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/pngwing.com_.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/pngwing.com-1.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/novastar-logo-vector.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/microsoft-logo-png-2396.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/logo-microvision-1.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/logo-asus-png-7165.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/kisspng-logo-brand-led-tv-123-cm-49-panasonic-tx-49fxw724-a-c-in-chinchilla-reids-chinchilla-refrigeratio-5b7b92e4472684.8625744815348251882914.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/kisspng-logo-acer-iconia-one-1-b3-a4-font-ivpro-sistemas-multimedia-5be977aef111c9.7007399315420271829874.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/kisspng-jakarta-laptop-axioo-mobile-phones-computer-ax-5ab6192b45a9a9.1471584015218834352853.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/kisspng-hewlett-packard-logo-lenovo-computer-software-lenovo-logo-5ac49fb086b243.2038317515228353765517.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/Hikvision-Logo.wine_.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/Hewlett_Packard_Enterprise-Logo.wine_-1.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/dji-logo.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/Dell_EMC-Logo.wine_-1.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/CDWTopgolf_newline.webp.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/624adb52cd30a2e30fc2a197_Logo_Philips_PDS_Small_HR-p-500.png?size=Woocommerce_thumbnail",
    "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/03/600f26befcd2b500043083e5.png?size=Woocommerce_thumbnail"
];
function Index(props) {
    const renderSlides = ()=>listImage.map((img, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                    alt: "product",
                    src: img,
                    width: 100,
                    height: 70
                })
            }, index));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "whychooseus-contain my-20 flex flex-col gap-1.5 m-auto w-4/5",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "title flex justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                    className: "font-bold border-b border-dark-primary mb-14 text-dark-primary text-2xl",
                    children: "Brand Partner"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "list-brand",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_slick__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    className: "",
                    dots: false,
                    slidesToShow: props.sizeScreen === "laptop" || props.sizeScreen === "tablet" ? 10 : 6,
                    autoplay: true,
                    autoplaySpeed: 2000,
                    infinite: true,
                    speed: 1000,
                    slidesToScroll: props.sizeScreen === "laptop" || props.sizeScreen === "tablet" ? 5 : 3,
                    children: renderSlides()
                })
            })
        ]
    });
}


/***/ }),

/***/ 7917:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Index)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/halamanUtama/whychoseus/elipsComponent.jsx


function CustomSvg() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "66",
        height: "66",
        viewBox: "0 0 66 66",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M62.5 33C62.5 49.2924 49.2924 62.5 33 62.5C16.7076 62.5 3.49997 49.2924 3.49997 33C3.49997 16.7076 16.7076 3.5 33 3.5C49.2924 3.5 62.5 16.7076 62.5 33Z",
                fill: "url(#paint0_radial_137_67)",
                stroke: "url(#paint1_linear_137_67)",
                strokeWidth: "7"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("defs", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("radialGradient", {
                        id: "paint0_radial_137_67",
                        cx: "0",
                        cy: "0",
                        r: "1",
                        gradientUnits: "userSpaceOnUse",
                        gradientTransform: "translate(33 33) rotate(90) scale(39.6)",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                stopColor: "#333333"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                offset: "0.34375",
                                stopColor: "#333333"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("linearGradient", {
                        id: "paint1_linear_137_67",
                        x1: "-19",
                        y1: "-32.5",
                        x2: "89.5",
                        y2: "83.5",
                        gradientUnits: "userSpaceOnUse",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                offset: "0.201175",
                                stopColor: "#9AD6EC"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                offset: "1",
                                stopColor: "#1937DA"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const elipsComponent = (CustomSvg);

;// CONCATENATED MODULE: ./src/components/halamanUtama/whychoseus/index.jsx




const whyChooseUsData = [
    {
        icon: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/puzzle-piece.png?size=Woocommerce_gallery_thumbnail",
        title: "Customized Solutions",
        description: "We provide tailored IT solutions that meet the unique needs of your business, maximizing efficiency and productivity."
    },
    {
        icon: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/diploma.png?size=Woocommerce_gallery_thumbnail",
        title: "Expertise",
        description: "Our team has years of experience in handling complex projects and delivering high-quality results."
    },
    {
        icon: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/social-network.png?size=Woocommerce_gallery_thumbnail",
        title: "Customer Satisfaction",
        description: "We prioritize customer satisfaction and work tirelessly to ensure that our solutions meet your expectations."
    },
    {
        icon: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/calendar-clock.png?size=Woocommerce_gallery_thumbnail",
        title: "Timely Delivery",
        description: "Our team is dedicated to meeting deadlines and delivering results that exceed your expectations."
    },
    {
        icon: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/rocket-1.png?size=Woocommerce_gallery_thumbnail",
        title: "Innovation",
        description: "We stay up-to-date with the latest advancements in technology and strive to incorporate innovative solutions into our services."
    },
    {
        icon: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/wallet.png?size=Woocommerce_gallery_thumbnail",
        title: "Competitive Pricing",
        description: "We offer competitive pricing for our services, ensuring that you receive high-quality IT solutions at an affordable cost."
    }
];
function Index() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "whychooseus-contain mt-20 flex flex-col gap-1.5 m-auto w-4/5",
        id: "about",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "title flex justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                    className: "font-bold border-b border-dark-primary mb-14 text-dark-primary text-2xl",
                    children: "Why Choose Us"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "list grid md:grid-cols-3 grid-cols-2 gap-10",
                children: whyChooseUsData.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "customized-solution w-full flex flex-col items-center justify-start",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon relative w-fit",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(elipsComponent, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "absolute top-1/2 left-1/2 transform -translate-x-1/2 ml-0.5 -translate-y-1/2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: item.icon,
                                            alt: "Gambar",
                                            width: 33,
                                            height: 33
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text mt-3 text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "font-bold",
                                        children: item.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "m-0 text-xs",
                                        children: item.description
                                    })
                                ]
                            })
                        ]
                    }, index))
            })
        ]
    });
}


/***/ }),

/***/ 923:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  "metadata": () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"src\\app\\layout.js","import":"Raleway","arguments":[{"subsets":["latin"],"variable":"--font-sofia"}],"variableName":"raleway"}
var target_path_src_app_layout_js_import_Raleway_arguments_subsets_latin_variable_font_sofia_variableName_raleway_ = __webpack_require__(9992);
var target_path_src_app_layout_js_import_Raleway_arguments_subsets_latin_variable_font_sofia_variableName_raleway_default = /*#__PURE__*/__webpack_require__.n(target_path_src_app_layout_js_import_Raleway_arguments_subsets_latin_variable_font_sofia_variableName_raleway_);
// EXTERNAL MODULE: ./src/components/Nav/Nav.js
var Nav = __webpack_require__(9338);
var Nav_default = /*#__PURE__*/__webpack_require__.n(Nav);
;// CONCATENATED MODULE: ./src/components/Nav/index.js


// EXTERNAL MODULE: ./src/app/globals.css
var globals = __webpack_require__(5553);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(5985);
;// CONCATENATED MODULE: ./src/components/Footer/Footer.js

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\dessi\Documents\belajar\CODEX\TESPROJECTDESAIN\next lentera\next-lentera\src\components\Footer\Footer.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
/* harmony default export */ const Footer = (proxy.default);

;// CONCATENATED MODULE: ./src/components/Footer/index.js


;// CONCATENATED MODULE: ./src/components/Main/Main.js

const Main = ({ children  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("main", {
        children: children
    });
};
/* harmony default export */ const Main_Main = (Main);

;// CONCATENATED MODULE: ./src/app/layout.js






const metadata = {
    title: "Lentera Inovasi",
    description: "Generated by create next app"
};
function RootLayout({ children  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("html", {
        lang: "en",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("head", {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
                className: (target_path_src_app_layout_js_import_Raleway_arguments_subsets_latin_variable_font_sofia_variableName_raleway_default()).variable,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Nav_default()), {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Main_Main, {
                        children: children
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer, {})
                ]
            })
        ]
    });
}


/***/ }),

/***/ 9394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5985);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\dessi\Documents\belajar\CODEX\TESPROJECTDESAIN\next lentera\next-lentera\src\app\page.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (proxy.default);


/***/ }),

/***/ 9338:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(5985);
module.exports = createProxy("C:\\Users\\dessi\\Documents\\belajar\\CODEX\\TESPROJECTDESAIN\\next lentera\\next-lentera\\src\\components\\Nav\\Nav.js");
 //testetestest


/***/ }),

/***/ 1764:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2548);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 5553:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [859,847], () => (__webpack_exec__(8446)));
module.exports = __webpack_exports__;

})();