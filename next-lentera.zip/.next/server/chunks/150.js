"use strict";
exports.id = 150;
exports.ids = [150];
exports.modules = {

/***/ 2150:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Carousel)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8217);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2330);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7738);






function Carousel(props) {
    const listImg = [
        {
            img: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/04/server-scaled.jpg?size=Thumbnail",
            name: "Server"
        },
        {
            img: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/04/office-furniture-scaled.jpg?size=Thumbnail",
            name: "Office Furniture"
        },
        {
            img: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/04/kamera-scaled.jpg?size=Thumbnail",
            name: "Camera"
        },
        {
            img: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/04/cctv-scaled.jpg?size=Thumbnail",
            name: "CCTV"
        },
        {
            img: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/videowall-scaled.jpg?size=Thumbnail",
            name: "Videowall"
        },
        {
            img: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/computer-and-printer-scaled.jpg?size=Thumbnail",
            name: "Computer & Printer"
        },
        {
            img: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/ac-scaled.jpg?size=Thumbnail",
            name: "Air Conditioner"
        },
        {
            img: "https://wp.lenterainovasi.co.id/wp-content/uploads/2023/05/networking-scaled.jpg?size=Thumbnail",
            name: "Networking"
        }
    ];
    const renderSlides = ()=>listImg.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `relative w-full ${props.sizeScreen == "hp" && "h-52"}`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "image-container",
                        style: {
                            height: props.sizeScreen !== "hp" && `${props.networkingAndComputerHeight}px`
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                            alt: "product",
                            src: item.img,
                            layout: "fill",
                            className: "w-full h-full object-cover"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `gradient-overlay-carousel absolute inset-0`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text text-white absolute bottom-3 left-3 text-start text-base sm:text-sm lg:text-base",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "font-semibold m-0",
                                children: item.name
                            })
                        })
                    })
                ]
            }, index));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: ` app product-list h-fit`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_slick__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            // className=""
            dots: true,
            slidesToShow: props.sizeScreen == "hp" ? 1 : 3,
            // slidesToShow={3}
            autoplay: true,
            autoplaySpeed: 2000,
            infinite: true,
            speed: 1000,
            slidesToScroll: 1,
            children: renderSlides()
        })
    });
}


/***/ })

};
;