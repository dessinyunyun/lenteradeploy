import Product from './Product/Product';
import AboutUs from './aboutUs/index';
import BrandPartner from './brandPartner/index';
import Whychoseus from './whychoseus/index';

export { Product, AboutUs, BrandPartner, Whychoseus };
